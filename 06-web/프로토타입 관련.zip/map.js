function MyMap() {
  this.key = [];
  this.value = [];
}

MyMap.prototype.put = function (key, value) {
  this.key.push(key);
  this.value.push(value);
}

MyMap.prototype.get = function (key) {
  var idx = this.key.indexOf(key);

  if (idx == -1) return undefined;
  else return this.value[idx];
}

MyMap.prototype.size = function () {
  return this.key.length;
}

MyMap.prototype.remove = function (key) {
  var idx = this.key.indexOf(key);
  if (idx == -1) return;
  else {
      this.key.splice(idx, 1);
      this.value.splice(idx, 1);
  }
}

MyMap.prototype.clear = function () {
  this.key = [];
  this.value = [];
}